Python 3.11.6

services.py has the functions only , inorder to launch the API use routes.py